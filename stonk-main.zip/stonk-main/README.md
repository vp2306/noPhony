#stonk
